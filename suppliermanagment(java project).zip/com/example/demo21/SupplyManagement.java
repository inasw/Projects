package com.example.demo21;//package com.example.demo1;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.Window;
class NegativeNumberException extends Exception {
    String message;
    NegativeNumberException(String str) {
        message = str;
    }
    public String toString() {
        return (" Exception Occurred : " + message);
    }
}

public class SupplyManagement extends Application {

    Admin administrator =new Admin();
    @Override

    public void start(Stage stage)  {
        Text text = new Text();
        Group root = new Group();
        Scene scene = new Scene(root, 250, 240, Color.BLUE);
        stage.setTitle("supply management system");
        text.setText("please choose the page");
        text.setX(10);
        text.setY(20);
        text.setFont(Font.font("Verdana", 17));
        Button buttonAdmin=new Button("Admin");
        Button buttonCashier=new Button("Cashier");
        Button buttonCustomer=new Button("Customer");
        Button buttonSupplier=new Button("Supplier");
        buttonCustomer.setLayoutY(45);
        buttonCustomer.setLayoutX(20);
        buttonCashier.setLayoutY(90);
        buttonCashier.setLayoutX(120);
        buttonAdmin.setLayoutY(45);
        buttonAdmin.setLayoutX(120);
        buttonSupplier.setLayoutY(90);
        buttonSupplier.setLayoutX(20);

        EventHandler<ActionEvent> eventadmin = actionEvent -> authenticate();
        EventHandler<ActionEvent> eventcashier = actionEvent -> administrator.redirect();
        EventHandler<ActionEvent> eventcustomer = actionEvent -> {

            if (administrator.cashier.size() != 0) {
                administrator.cashier.get(0).login();
            } else {
                System.out.println("no cashier found");
            }
        };
        EventHandler<ActionEvent> eventSupplier = actionEvent -> {
            if(administrator.cashier.size()!=0){
                administrator.cashier.get(0).loginToSupplier();
            }
            else{
                System.out.println("no cashier found");
            }

        };
        buttonAdmin.setOnAction(eventadmin);
        buttonCashier.setOnAction(eventcashier);
        buttonCustomer.setOnAction(eventcustomer);
        buttonSupplier.setOnAction(eventSupplier);
        root.getChildren().add(buttonSupplier);
        root.getChildren().add(text);
        root.getChildren().add(buttonAdmin);
        root.getChildren().add(buttonCashier);
        root.getChildren().add(buttonCustomer);
        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();
    }




public void authenticate() {
        String passKey="1234";
    Stage stagee = new Stage();
    Group roots = new Group();
    Button go = new Button("go");
    PasswordField passwordField = new PasswordField();
    passwordField.setPromptText("password");
    Text text = new Text();
    passwordField.setLayoutY(20);
        passwordField.setLayoutX(30);
        go.setLayoutY(60);
        go.setLayoutX(50.0);
    EventHandler<ActionEvent> eventego = new EventHandler<ActionEvent>() {
        public void handle(ActionEvent actionEvent) {
            if(passwordField.getText().equals("")){
                text.setText("please fill the password ");
            }
           else if(passwordField.getText().equals(passKey)){
                Window currentWindow = ((Node)actionEvent.getSource()).getScene().getWindow();
                currentWindow.hide();
                adminPage();

            }
            else{

            text.setText("you are not administrator of the page");
        }}
    };
         text.setLayoutY(100);
         text.setLayoutX(30);
         roots.getChildren().add(text);
         roots.getChildren().add(passwordField);
         roots.getChildren().add(go);
         Scene scenes = new Scene(roots, 250, 240, Color.BLUE);
         go.setOnAction(eventego);
         stagee.setScene(scenes);
         stagee.show();
}



    public void adminPage(){

        Button addCashier=new Button("add cashier");
        Button editCashierInfo=new Button("edit cashier info");
        Button showAllCashiers=new Button("show all cashiers");
        Button removeCashier=new Button("remove cashier");
        Button login=new Button("login");
        Group rootAdmin = new Group();
        Text textAdmin=new Text();
        textAdmin.setLayoutY(30);   textAdmin.setLayoutX(40);
        addCashier.setLayoutY(40);  addCashier.setLayoutX(80);
        editCashierInfo.setLayoutY(70);    editCashierInfo.setLayoutX(80);
        showAllCashiers.setLayoutY(100);    showAllCashiers.setLayoutX(80);
        removeCashier.setLayoutY(130);      removeCashier.setLayoutX(80);
        login.setLayoutY(160);      login.setLayoutX(80);
        textAdmin.setText("admin page");
        EventHandler<ActionEvent> editCashierInfoEvent = actionEvent -> administrator.edit();           editCashierInfo.setOnAction(editCashierInfoEvent);
        EventHandler<ActionEvent> showAllCashiersEvent = actionEvent -> administrator.display();             showAllCashiers.setOnAction(showAllCashiersEvent);
        EventHandler<ActionEvent> removeCashierEvent = actionEvent -> administrator.remove();        removeCashier.setOnAction(removeCashierEvent);
        EventHandler<ActionEvent> loginEvent = actionEvent -> administrator.redirect();        login.setOnAction(loginEvent);
        EventHandler<ActionEvent> addcashierEvent = actionEvent -> {
            Window currentWindow = ((Node)actionEvent.getSource()).getScene().getWindow();
            currentWindow.hide();
            administrator.addCashier();
        };
        addCashier.setOnAction(addcashierEvent);

        Scene sceneAdmin = new Scene(rootAdmin, 343, 490, Color.BLUE);
        rootAdmin.getChildren().add(login);
        rootAdmin.getChildren().add(textAdmin);
        rootAdmin.getChildren().add(addCashier);
        rootAdmin.getChildren().add(editCashierInfo);
        rootAdmin.getChildren().add(showAllCashiers);
        rootAdmin.getChildren().add(removeCashier);
        Stage newStage = new Stage();
        newStage.setTitle("admin page");
        newStage.setScene(sceneAdmin);
        newStage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}


