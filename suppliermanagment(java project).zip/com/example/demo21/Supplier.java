package com.example.demo21;
import com.example.Item.*;
import javafx.application.Application;
import javafx.stage.Stage;

public class Supplier extends Application {
    public void start(Stage stage) {
    }

    private int creditNumber;
    private String address;
    public String name;

    public Supplier() {
        System.out.println(" ");
    }

    public void setCreditNumber(int credit_number) {
        this.creditNumber = credit_number;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getCreditNumber() {
        return creditNumber;
    }

    public String getAddress() {
        return address;
    }

    public void sell() {
        Cashier cashier = new Cashier();
        cashier.addProduct();
    }
}
