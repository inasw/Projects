package com.example.demo21;
import com.example.Item.*;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.util.ArrayList;

public class Admin extends Application {
    ArrayList<Cashier> cashier = new ArrayList<>();


    public void start(Stage stage) {
    }

    void addCashier() {
        TextField textFieldName = new TextField();
        textFieldName.setPromptText("Name");

        textFieldName.setTextFormatter(new TextFormatter<>(change -> {
            if (change.getControlNewText().matches("[a-zA-Z]*")) {
                return change;
            }
            return null;
        }));


        PasswordField password = new PasswordField();
        password.setPromptText("password");
        Group root = new Group();
        Scene sceneAdmin = new Scene(root, 400, 300, Color.BLUE);
        Button add = new Button("save");
        Button back = new Button("back");
        add.setLayoutX(30);
        add.setLayoutY(80);
        back.setLayoutX(80);
        back.setLayoutY(80);
        textFieldName.setLayoutX(0);
        textFieldName.setLayoutY(30);
        password.setLayoutX(200);
        password.setLayoutY(30);
        EventHandler<ActionEvent> addb = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                if(password.getText().equals("")||textFieldName.getText().equals("")){
                    System.out.println("no data entered ");
                }
                else{
                Cashier cashierTemp = new Cashier();
                cashierTemp.password = password.getText();
                cashierTemp.name = textFieldName.getText();
                cashier.add(cashierTemp);
                Text text1 = new Text("added");
                text1.setLayoutX(10);
                text1.setLayoutY(140);
                root.getChildren().add(text1);
            }}
        };
        add.setOnAction(addb);

        EventHandler<ActionEvent> backb = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                Window currentWindow = ((Node) actionEvent.getSource()).getScene().getWindow();
                currentWindow.hide();
            }
        };
        back.setOnAction(backb);
        root.getChildren().add(add);
        root.getChildren().add(back);
        root.getChildren().add(textFieldName);
        root.getChildren().add(password);
        Stage newStage = new Stage();
        newStage.setTitle("admin page");
        newStage.setScene(sceneAdmin);
        newStage.show();
    }


    public void edit() {
        Stage stage = new Stage();
        Group root = new Group();
        Button buttonRemove = new Button("edit info");
        TextField textarea = new TextField();
        textarea.setLayoutY(20);
        textarea.setLayoutX(30.0);
        textarea.setPromptText("enter the name");
        buttonRemove.setLayoutY(60);
        buttonRemove.setLayoutX(30.0);
        EventHandler<ActionEvent> eventedit = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                Text text = new Text();
                Boolean found = false;
                if (cashier.size() != 0) {
                    String name = textarea.getText();
                    for (int i = 0; i < cashier.size(); i++) {
                        if (cashier.get(i).name.equals(name)) {
                            cashier.remove(i);
                            found = true;
                            text.setText("now edit info ");

                        }
                    }
                    if (found) {
                        addCashier();
                        Window currentWindow = ((Node) actionEvent.getSource()).getScene().getWindow();
                        currentWindow.hide();
                    } else {
                        text.setText("not found ");
                    }
                } else {
                    text.setText("you have no data ");
                }
                text.setLayoutY(120);
                text.setLayoutX(30);
                root.getChildren().add(text);
            }
        };
        root.getChildren().add(textarea);
        root.getChildren().add(buttonRemove);
        Scene scene = new Scene(root, 400, 200, Color.BLUE);
        buttonRemove.setOnAction(eventedit);
        stage.setScene(scene);
        stage.show();


    }


    public void display() {
        Stage stage = new Stage();
        Text[] texts = new Text[cashier.size()];
        Text[] password = new Text[cashier.size()];
        Group root = new Group();
//        Pane rot=new Pane();
        Button buttonGo = new Button("Go back");
        double layy = 165;
        buttonGo.setLayoutY(layy);
        buttonGo.setLayoutX(182.0);
        EventHandler<ActionEvent> eventGO = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                Window currentWindow = ((Node) actionEvent.getSource()).getScene().getWindow();
                currentWindow.hide();
            }
        };
        Scene scene = new Scene(root, 343, 433, Color.BLUE);
        stage.setTitle("display page");
        if (cashier.size() == 0) {
            Text text = new Text();
            text.setText("none");
            text.setX(39);
            text.setY(39);
            text.setLayoutX(65);
            text.setLayoutY(110.0);
            text.setFont(Font.font("Verdana", 17));
            root.getChildren().add(text);
        } else {
            Text text = new Text("name");
            Text password1 = new Text("password");
            text.setX(39);
            text.setY(39);
            password1.setX(90);
            password1.setY(39);
            int y = 39;
            root.getChildren().add(text);
            root.getChildren().add(password1);
            try {
                for (int i = 0; i < cashier.size(); i++) {
                    y += 20;
                    layy += 20;
                    texts[i] = new Text(1 + "." + cashier.get(i).name);
                    texts[i].setLayoutY(y);
                    texts[i].setLayoutX(39);
                    password[i] = new Text("    " + cashier.get(i).password);
                    password[i].setLayoutY(y);
                    password[i].setLayoutX(90);

                    buttonGo.setLayoutY(165.0 + layy);
                }
            } catch (NullPointerException e) {
                texts[0] = new Text("null ");
            }
            root.getChildren().addAll(texts);
            root.getChildren().addAll(password);
        }
        root.getChildren().add(buttonGo);
        buttonGo.setOnAction(eventGO);
        stage.setScene(scene);
        stage.show();

    }


    public void remove() {
        Stage stage = new Stage();
        Group root = new Group();
        Button buttonRemove = new Button("remove");
        TextField textarea = new TextField();
        textarea.setLayoutY(20);
        textarea.setLayoutX(30.0);
        buttonRemove.setLayoutY(60);
        buttonRemove.setLayoutX(30.0);
        EventHandler<ActionEvent> eventRemove = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                Text text = new Text();
                if (cashier.size() != 0) {
                    String name = textarea.getText();
                    for (int i = 0; i < cashier.size(); i++) {

                        if (cashier.get(i).name.equals(name)) {
                            cashier.remove(i);
                            text.setText("removed");
                        }
                    }
                } else {
                    text.setText("not registered yet ");
                }
                text.setLayoutY(110);
                text.setLayoutX(30);
                root.getChildren().add(text);
            }
        };
        root.getChildren().add(textarea);
        root.getChildren().add(buttonRemove);
        Scene scene = new Scene(root, 400, 200, Color.BLUE);
        buttonRemove.setOnAction(eventRemove);
        stage.setScene(scene);
        stage.show();
    }


    public void login() {
        int index = 0;//cashier
        Group root = new Group();
        Button button1 = new Button("add product ");
        button1.setLayoutX(20);
        button1.setLayoutY(10);
        Button button2 = new Button("add customer");
        button2.setLayoutX(20);
        button2.setLayoutY(40);
        Button button3 = new Button("search product");
        button3.setLayoutX(20);
        button3.setLayoutY(70);
        Button button4 = new Button("search customer");
        button4.setLayoutX(20);
        button4.setLayoutY(100);
        root.getChildren().add(button4);
        Button button5 = new Button("update info ");
        button5.setLayoutX(200);
        button5.setLayoutY(10);
        root.getChildren().add(button5);
        Button button6 = new Button("show customers");
        button6.setLayoutX(200);
        button6.setLayoutY(40);
        root.getChildren().add(button6);
        Button button7 = new Button("show products");
        button7.setLayoutX(200);
        button7.setLayoutY(70);
        root.getChildren().add(button7);
        Button button9 = new Button("delete");
        button9.setLayoutX(200);
        button9.setLayoutY(100);
        root.getChildren().add(button9);
        Button button10 = new Button("exit");
        button10.setLayoutX(20);
        button10.setLayoutY(130);
        Button button12 = new Button("Add supplier");
        button12.setLayoutY(130);
        button12.setLayoutX(200);
        Button button13 = new Button("show suppliers");
        button13.setLayoutY(160);
        button13.setLayoutX(20);
        root.getChildren().add(button12);
        root.getChildren().add(button13);
        root.getChildren().add(button10);
        root.getChildren().add(button1);
        root.getChildren().add(button2);
        root.getChildren().add(button3);
        Stage stage = new Stage();
        stage.setTitle("cashier page");

        EventHandler<ActionEvent> button12E = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                cashier.get(index).addSupplier();
            }
        };
        button12.setOnAction(button12E);

        EventHandler<ActionEvent> button13E = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                try{
                cashier.get(index).showSupplier();}
                catch (NullPointerException e){
                    System.out.println(e);
                }
            }
        };
        button13.setOnAction(button13E);
        EventHandler<ActionEvent> button1E = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                cashier.get(index).addProduct();
            }
        };
        button1.setOnAction(button1E);
        EventHandler<ActionEvent> button2E = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                cashier.get(index).addCustomer();
            }
        };
        button2.setOnAction(button2E);
        EventHandler<ActionEvent> button3E = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                cashier.get(index).searchProduct();
            }
        };
        button3.setOnAction(button3E);
        EventHandler<ActionEvent> button4E = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                cashier.get(index).searchCustomer();
            }
        };
        button4.setOnAction(button4E);
        EventHandler<ActionEvent> button5E = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                cashier.get(index).update();
            }
        };
        button5.setOnAction(button5E);
        EventHandler<ActionEvent> button6E = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                cashier.get(index).showAllCustomers();
            }
        };
        button6.setOnAction(button6E);
        EventHandler<ActionEvent> button7E = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                cashier.get(index).showAllProducts();
            }
        };
        button7.setOnAction(button7E);
        EventHandler<ActionEvent> button8E = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                redirect();
            }
        };
//        button8.setOnAction(button8E);
        EventHandler<ActionEvent> button9E = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                cashier.get(index).delete();
            }
        };
        button9.setOnAction(button9E);
        EventHandler<ActionEvent> button10E = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                cashier.get(index).exit();
            }
        };

        button10.setOnAction(button10E);
        Scene scene = new Scene(root, 343, 433, Color.BLUE);
        stage.setScene(scene);
        stage.show();

    }

    public void redirect() {


        Stage stagee = new Stage();
        Group roots = new Group();
        Button buttonRemove = new Button("go");
        TextField textarea = new TextField();
        PasswordField passwordField = new PasswordField();
        textarea.setLayoutY(20);
        textarea.setLayoutX(30.0);
        passwordField.setLayoutY(20);
        passwordField.setLayoutX(200);
        passwordField.setPromptText("password");
        textarea.setPromptText("name?");
        buttonRemove.setLayoutY(60);
        buttonRemove.setLayoutX(30.0);
        EventHandler<ActionEvent> eventedit = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                Text text = new Text();
                Boolean found = false;
                if (cashier.size() != 0) {
                    for (int i = 0; i < cashier.size(); i++) {
                        if (cashier.get(i).name.equals(textarea.getText())) {
                            if (cashier.get(i).password.equals(passwordField.getText())) {
                                login();
                                Window currentWindow = ((Node) actionEvent.getSource()).getScene().getWindow();
                                currentWindow.hide();
                                found = true;
                                break;
                            }
                        }
                    }
                    if (!found) {
                        text.setText("not found ");
                    }
                } else {
                    text.setText("you are not registered by the system ");
                }
                text.setLayoutY(100);
                text.setLayoutX(30);
                roots.getChildren().add(text);
            }
        };
        roots.getChildren().add(textarea);
        roots.getChildren().add(passwordField);
        roots.getChildren().add(buttonRemove);
        Scene scenes = new Scene(roots, 400, 200, Color.BLUE);
        buttonRemove.setOnAction(eventedit);
        stagee.setScene(scenes);
        stagee.show();
    }
}