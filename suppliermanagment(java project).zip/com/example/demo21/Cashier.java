package com.example.demo21;
import com.example.Item.*;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.util.ArrayList;

public class Cashier extends Application {

    public void start(Stage stage) {
        stage.setTitle("cashier page ");
    }

    static ArrayList<Customer> customer = new ArrayList<>();
    static ArrayList<Supplier> suppliers = new ArrayList<>();
    static ArrayList<Item> item = new ArrayList<>();

    public Cashier() {
        System.out.println(" ");
    }

    public String password;
    public String name;


    public void addProduct() {
        TextField textFieldName = new TextField();
        textFieldName.setPromptText("Name");
        TextField textFieldquantity = new TextField();
        textFieldquantity.setPromptText("quantity");
        TextField textFieldPrice = new TextField();
        textFieldPrice.setPromptText("price");
        Group root = new Group();
        Scene sceneAdmin = new Scene(root, 400, 300, Color.BLUE);
        Button add = new Button("save");
        Button back = new Button("back");
        add.setLayoutX(30);
        add.setLayoutY(90);
        back.setLayoutX(80);
        back.setLayoutY(90);
        textFieldName.setLayoutX(0);
        textFieldName.setLayoutY(30);
        textFieldquantity.setLayoutX(200);
        textFieldquantity.setLayoutY(30);
        textFieldPrice.setLayoutX(100);
        textFieldPrice.setLayoutY(60);
        EventHandler<ActionEvent> addb = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                Boolean exists = false;
                int ind = -1;

                Item itemTemp = new Item();
                itemTemp.setName(textFieldName.getText());
                try {
                    itemTemp.setQuantity(Integer.parseInt(textFieldquantity.getText()));
                } catch (NumberFormatException e) {
                    System.out.println("number format error ");
                    return;
                }
                itemTemp.setPrice(Float.parseFloat(textFieldPrice.getText()));

                for (int i = 0; i < item.size(); i++) {
                    if (itemTemp.getName().equals(item.get(i).getName())) {
                        exists = true;
                        ind = i;
                    }
                }
                if (exists) {
                    item.get(ind).setQuantity(itemTemp.getQuantity() + item.get(ind).getQuantity());
                    item.get(ind).setPrice(itemTemp.getPrice());
                } else {
                    item.add(itemTemp);
                }
                Text text = new Text("saved");
                text.setLayoutX(10);
                text.setLayoutY(140);
                root.getChildren().add(text);
            }
        };
        add.setOnAction(addb);

        EventHandler<ActionEvent> backb = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                Window currentWindow = ((Node) actionEvent.getSource()).getScene().getWindow();
                currentWindow.hide();
            }
        };
        back.setOnAction(backb);
        root.getChildren().add(add);
        root.getChildren().add(back);
        root.getChildren().add(textFieldName);
        root.getChildren().add(textFieldPrice);
        root.getChildren().add(textFieldquantity);
        Stage newStage = new Stage();
        newStage.setTitle(" add product");
        newStage.setScene(sceneAdmin);
        newStage.show();
    }


    public void addSupplier() {
        TextField textFieldName = new TextField();
        textFieldName.setPromptText("Name");
        TextField tetFieldAddress = new TextField();
        tetFieldAddress.setPromptText("Adderss");

        textFieldName.setTextFormatter(new TextFormatter<>(change -> {
            if (change.getControlNewText().matches("[a-zA-Z]*")) {
                return change;
            }
            return null;
        }));
        tetFieldAddress.setTextFormatter(new TextFormatter<>(change -> {
            if (change.getControlNewText().matches("[a-zA-Z]*")) {
                return change;
            }
            return null;
        }));

        TextField textFieldCredit = new TextField();
        textFieldCredit.setPromptText("credit number");

        textFieldCredit.setTextFormatter(new TextFormatter<>(change -> {
            if (change.getControlNewText().matches("[0-9]*")) {
                return change;
            }
            return null;
        }));


        Group root = new Group();
        Scene sceneAdmin = new Scene(root, 400, 300, Color.BLUE);
        Button add = new Button("save");
        Button back = new Button("back");
        add.setLayoutX(30);
        add.setLayoutY(90);
        back.setLayoutX(80);
        back.setLayoutY(90);
        textFieldName.setLayoutX(0);
        textFieldName.setLayoutY(30);
        tetFieldAddress.setLayoutX(200);
        tetFieldAddress.setLayoutY(30);
        textFieldCredit.setLayoutX(100);
        textFieldCredit.setLayoutY(60);
        EventHandler<ActionEvent> addE = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                Supplier supplier = new Supplier();
                supplier.setAddress(tetFieldAddress.getText());
                supplier.name = textFieldName.getText();
                supplier.setCreditNumber(Integer.parseInt(textFieldCredit.getText()));
                suppliers.add(supplier);
                Text text = new Text("saved");
                text.setLayoutX(10);
                text.setLayoutY(140);
                root.getChildren().add(text);
            }
        };
        add.setOnAction(addE);

        EventHandler<ActionEvent> backb = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                Window currentWindow = ((Node) actionEvent.getSource()).getScene().getWindow();
                currentWindow.hide();
            }
        };
        back.setOnAction(backb);
        root.getChildren().add(add);
        root.getChildren().add(back);
        root.getChildren().add(textFieldName);
        root.getChildren().add(textFieldCredit);
        root.getChildren().add(tetFieldAddress);
        Stage newStage = new Stage();
        newStage.setTitle("cashier page");
        newStage.setScene(sceneAdmin);
        newStage.show();

    }

    public void addCustomer() {
        TextField textFieldName = new TextField();
        textFieldName.setPromptText("Name");
        textFieldName.setTextFormatter(new TextFormatter<>(change -> {
            if (change.getControlNewText().matches("[a-zA-Z]*")) {
                return change;
            }
            return null;
        }));
        TextField tetFieldAddress = new TextField();
        tetFieldAddress.setPromptText("Adderss");
        TextField textFieldCredit = new TextField();
        textFieldCredit.setPromptText("credit number");
        Group root = new Group();
        Scene sceneAdmin = new Scene(root, 400, 300, Color.BLUE);
        Button add = new Button("save");
        Button back = new Button("back");
        add.setLayoutX(30);
        add.setLayoutY(90);
        back.setLayoutX(80);
        back.setLayoutY(90);
        textFieldName.setLayoutX(0);
        textFieldName.setLayoutY(30);
        tetFieldAddress.setLayoutX(200);
        tetFieldAddress.setLayoutY(30);
        textFieldCredit.setLayoutX(100);
        textFieldCredit.setLayoutY(60);
        EventHandler<ActionEvent> addb = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                Customer customerTemp = new Customer();
                customerTemp.setClientAddress(tetFieldAddress.getText());
                customerTemp.name = textFieldName.getText();
                customerTemp.setCreditNumber(Integer.parseInt(textFieldCredit.getText()));
                customer.add(customerTemp);
                Text text = new Text("saved");
                text.setLayoutX(10);
                text.setLayoutY(140);
                root.getChildren().add(text);
            }
        };
        add.setOnAction(addb);

        EventHandler<ActionEvent> backb = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                Window currentWindow = ((Node) actionEvent.getSource()).getScene().getWindow();
                currentWindow.hide();
            }
        };
        back.setOnAction(backb);
        root.getChildren().add(add);
        root.getChildren().add(back);
        root.getChildren().add(textFieldName);
        root.getChildren().add(textFieldCredit);
        root.getChildren().add(tetFieldAddress);
        Stage newStage = new Stage();
        newStage.setTitle("casheir page");
        newStage.setScene(sceneAdmin);
        newStage.show();

    }

    public void searchProduct() {
        Text text = new Text();
        TextField textFieldName = new TextField();
        textFieldName.setPromptText("Name");
        Group root = new Group();
        Scene sceneAdmin = new Scene(root, 400, 300, Color.BLUE);
        Button add = new Button("search");
        Button back = new Button("back");
        add.setLayoutX(30);
        add.setLayoutY(90);
        back.setLayoutX(120);
        back.setLayoutY(90);
        textFieldName.setLayoutX(0);
        textFieldName.setLayoutY(30);
        EventHandler<ActionEvent> addb = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                Boolean found = false;
                for (Item i : item) {
                    if (i.getName().equals(textFieldName.getText())) {
                        found = true;
                        text.setText("name " + i.getName() + "\tprice " + i.getPrice() + "\tquantity " + i.getQuantity());

                    }
                }
                if (!found) {

                    text.setText("not found ");
                }

            }

        };
        add.setOnAction(addb);

        EventHandler<ActionEvent> backb = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                Window currentWindow = ((Node) actionEvent.getSource()).getScene().getWindow();
                currentWindow.hide();
            }
        };
        text.setLayoutX(30);
        text.setLayoutY(70);
        root.getChildren().add(text);
        back.setOnAction(backb);
        root.getChildren().add(add);
        root.getChildren().add(back);
        root.getChildren().add(textFieldName);
        Stage newStage = new Stage();
        newStage.setTitle("cashier page");
        newStage.setScene(sceneAdmin);
        newStage.show();

    }

    public void searchCustomer() {
        Text text = new Text();
        TextField textFieldName = new TextField();
        textFieldName.setPromptText("Name");
        Group root = new Group();
        Scene sceneAdmin = new Scene(root, 400, 300, Color.BLUE);
        Button add = new Button("search");
        Button back = new Button("back");
        add.setLayoutX(30);
        add.setLayoutY(90);
        back.setLayoutX(130);
        back.setLayoutY(90);
        textFieldName.setLayoutX(0);
        textFieldName.setLayoutY(30);
        EventHandler<ActionEvent> addb = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                Boolean found = false;
                for (Customer i : customer) {
                    if (i.name.equals(textFieldName.getText())) {
                        found = true;
                        text.setText("name " + i.name + "\taddress" + i.getClientAddress() + "\tcredit card number" + i.getCreditNumber());
                    }
                }
                if (!found) {

                    text.setText("not found ");

                }

            }
        };
        add.setOnAction(addb);

        EventHandler<ActionEvent> backb = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                Window currentWindow = ((Node) actionEvent.getSource()).getScene().getWindow();
                currentWindow.hide();
            }
        };
        back.setOnAction(backb);
        text.setLayoutX(30);
        text.setLayoutY(70);
        root.getChildren().add(text);
        root.getChildren().add(add);
        root.getChildren().add(back);
        root.getChildren().add(textFieldName);
        Stage newStage = new Stage();
        newStage.setTitle("admin page");
        newStage.setScene(sceneAdmin);
        newStage.show();

    }

    public void update() {
        TextField textFieldName = new TextField();
        textFieldName.setPromptText("name");
        textFieldName.setLayoutX(0);
        textFieldName.setLayoutY(30);
        Group root = new Group();
        Scene sceneAdmin = new Scene(root, 400, 300, Color.BLUE);
        Button productButton = new Button("update product ");
        Button customerButton = new Button("update customer info ");
        productButton.setLayoutX(10);
        productButton.setLayoutY(90);
        customerButton.setLayoutX(150);
        customerButton.setLayoutY(90);
        EventHandler<ActionEvent> customerEvent = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                Boolean found = false;
                if ((textFieldName.getText()).length() != 0) {
                    for (int i = 0; i < customer.size(); i++) {
                        if (customer.get(i).name.equals(textFieldName.getText())) {
                            customer.remove(i);
                            Window currentWindow = ((Node) actionEvent.getSource()).getScene().getWindow();
                            currentWindow.hide();
                            found = true;
                            addCustomer();
                        }
                    }
                    if (!found) {

                        Label text = new Label("not found ");
                        text.setLayoutX(80);
                        text.setLayoutY(50);
                        root.getChildren().add(text);
                    }
                } else {
                    Text text = new Text("please enter data before editing ");
                    text.setLayoutX(80);
                    text.setLayoutY(50);
                    root.getChildren().add(text);
                }
            }
        };
        customerButton.setOnAction(customerEvent);

        EventHandler<ActionEvent> productEvent = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {

                Boolean found = false;
                if ((textFieldName.getText()).length() != 0) {
                    for (int i = 0; i < item.size(); i++) {
                        if (item.get(i).getName().equals(textFieldName.getText())) {
                            if (item.get(i).getName().equals(textFieldName.getText())) {
                                item.remove(i);
                                found = true;
                                addProduct();
                            }
                        }
                    }
                    if (!found) {

                        Text text = new Text("not found ");
                        text.setLayoutX(80);
                        text.setLayoutY(50);
                        root.getChildren().add(text);
                    }
                } else {
                    Text text = new Text("please enter data before editing ");
                    text.setLayoutX(80);
                    text.setLayoutY(50);
                    root.getChildren().add(text);
                }
            }
        };
        productButton.setOnAction(productEvent);
        root.getChildren().add(productButton);
        root.getChildren().add(customerButton);
        root.getChildren().add(textFieldName);
        Stage newStage = new Stage();
        newStage.setTitle("admin page");
        newStage.setScene(sceneAdmin);
        newStage.show();

    }


    public void delete() {
        Text text = new Text();
        TextField textFieldName = new TextField();
        textFieldName.setPromptText(name);

        textFieldName.setLayoutX(0);
        textFieldName.setLayoutY(30);
        Group root = new Group();
        Scene sceneAdmin = new Scene(root, 400, 300, Color.BLUE);
        Button productButton = new Button("delete product ");
        Button customerButton = new Button("delete customer ");
        productButton.setLayoutX(10);
        productButton.setLayoutY(90);
        customerButton.setLayoutX(150);
        customerButton.setLayoutY(90);
        EventHandler<ActionEvent> addb = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                Boolean found = false;
                if ((textFieldName.getText()).length() != 0) {
                    for (int i = 0; i < customer.size(); i++) {
                        if (customer.get(i).name.equals(textFieldName.getText())) {
                            customer.remove(i);
                            text.setText("deleted");
                            Window currentWindow = ((Node) actionEvent.getSource()).getScene().getWindow();
                            currentWindow.hide();
                            found = true;
                        }
                    }
                    if (!found) {

                        Label text = new Label("not found ");
                        text.setLayoutX(80);
                        text.setLayoutY(50);
                        root.getChildren().add(text);
                    }
                } else {
                    Text text = new Text("please enter data before editing ");
                    text.setLayoutX(80);
                    text.setLayoutY(50);
                    root.getChildren().add(text);
                }
            }
        };
        customerButton.setOnAction(addb);

        EventHandler<ActionEvent> backb = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {

                Boolean found = false;
                if ((textFieldName.getText()).length() != 0) {
                    for (int i = 0; i < item.size(); i++) {
                        if (item.get(i).getName().equals(textFieldName.getText())) {
                            if (item.get(i).getName().equals(textFieldName.getText())) {
                                item.remove(i);
                                text.setText("deleted");
                                found = true;
                                Window currentWindow = ((Node) actionEvent.getSource()).getScene().getWindow();
                                currentWindow.hide();
                            }
                        }
                    }
                    if (!found) {

                        Text text = new Text("not found ");
                        text.setLayoutX(80);
                        text.setLayoutY(50);
                        root.getChildren().add(text);
                    }
                } else {
                    Text text = new Text("please enter data before editing ");
                    text.setLayoutX(80);
                    text.setLayoutY(50);
                    root.getChildren().add(text);
                }
            }
        };
        productButton.setOnAction(backb);
        root.getChildren().add(text);

        root.getChildren().add(productButton);
        root.getChildren().add(customerButton);
        root.getChildren().add(textFieldName);
        Stage newStage = new Stage();
        newStage.setTitle("admin page");
        newStage.setScene(sceneAdmin);
        newStage.show();
    }

    public void exit() {
        System.exit(0);
    }

    public void showAllCustomers() {


        Stage stage = new Stage();
        Text[] texts = new Text[customer.size()];
        Group root = new Group();
        Button buttonGo = new Button("Go back");
        double layy = 165;
        buttonGo.setLayoutY(layy);
        buttonGo.setLayoutX(182.0);
        EventHandler<ActionEvent> eventGO = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                Window currentWindow = ((Node) actionEvent.getSource()).getScene().getWindow();
                currentWindow.hide();
            }
        };
        Scene scene = new Scene(root, 343, 433, Color.BLUE);
        stage.setTitle("display page");
        if (customer.size() == 0) {
            Text text = new Text();
            text.setText("none");
            text.setX(39);
            text.setY(39);
            text.setLayoutX(65);
            text.setLayoutY(110.0);
            text.setFont(Font.font("Verdana", 17));
            root.getChildren().add(text);
        } else {
            try {
                int y = 0;
                for (int i = 0; i < customer.size(); i++) {
                    y += 20;
                    layy += 20;
                    texts[i] = new Text("name: " + customer.get(i).name + "\taddress: " + customer.get(i).getClientAddress() + "\tcard: " + customer.get(i).getCreditNumber());
                    texts[i].setLayoutY(y);
                    texts[i].setLayoutX(39);
                    buttonGo.setLayoutY(layy);
                }
            } catch (NullPointerException e) {
                texts[0] = new Text("null ");
            }
            root.getChildren().addAll(texts);
        }
        root.getChildren().add(buttonGo);
        buttonGo.setOnAction(eventGO);
        stage.setScene(scene);
        stage.show();

    }

    public void showSupplier() {
        Stage stage = new Stage();
        Text[] texts = new Text[suppliers.size()];
        Group root = new Group();
        Button buttonGo = new Button("Go back");
        double layy = 165;
        buttonGo.setLayoutY(layy);
        buttonGo.setLayoutX(182.0);
        EventHandler<ActionEvent> eventGO = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                Window currentWindow = ((Node) actionEvent.getSource()).getScene().getWindow();
                currentWindow.hide();
            }
        };
        Scene scene = new Scene(root, 343, 433, Color.BLUE);
        stage.setTitle("cashier page");
        if (suppliers.size() == 0) {
            Text text = new Text();
            text.setText("none");
            text.setX(39);
            text.setY(39);
            text.setLayoutX(65);
            text.setLayoutY(110.0);
            text.setFont(Font.font("Verdana", 17));
            root.getChildren().add(text);
        } else {
            System.out.println(suppliers.get(0).name + "\taddress: " + suppliers.get(0).getAddress());
            try {
                int y = 0;
                for (int j = 0; j < suppliers.size(); j++) {
                    y += 20;
                    layy += 20;
                    try {
                        texts[j] = new Text("name: " + suppliers.get(j).name + "\taddress: " + suppliers.get(j).getAddress() + "\tcard: " + suppliers.get(j).getCreditNumber());
                        texts[j].setLayoutY(y);
                        texts[j].setLayoutX(39);
                        buttonGo.setLayoutY(layy);
                    } catch (ArrayIndexOutOfBoundsException e) {
                        System.out.println("out of bound");
                    }
                }
            } catch (NullPointerException e) {
                texts[0] = new Text("null ");
            }
        }
        root.getChildren().addAll(texts);
        root.getChildren().add(buttonGo);
        buttonGo.setOnAction(eventGO);
        stage.setScene(scene);
        stage.show();
    }

    public void showAllProducts() {

        Stage stage = new Stage();
        Text[] texts = new Text[item.size()];
        Group root = new Group();
//        Pane rot=new Pane();
        Button buttonGo = new Button("Go back");
        double layy = 165;
        buttonGo.setLayoutY(layy);
        buttonGo.setLayoutX(182.0);
        EventHandler<ActionEvent> eventGO = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                Window currentWindow = ((Node) actionEvent.getSource()).getScene().getWindow();
                currentWindow.hide();
            }
        };
        Scene scene = new Scene(root, 343, 433, Color.BLUE);
        stage.setTitle("display page");
        if (item.size() == 0) {
            Text text = new Text();
            text.setText("none");
            text.setX(39);
            text.setY(39);
            text.setLayoutX(65);
            text.setLayoutY(110.0);
            text.setFont(Font.font("Verdana", 17));
            root.getChildren().add(text);
        } else {
            try {
                int y = 0;
                int ind = 0;
                for (Item i : item) {
                    y += 20;
                    layy += 20;
                    texts[ind] = new Text("name :" + i.getName() + "\tprice :" + i.getPrice() + "\tquantity :" + i.getQuantity());
                    texts[ind].setLayoutY(y);
                    texts[ind].setLayoutX(39);
                    buttonGo.setLayoutY(layy);
                    ind++;
                }
            } catch (NullPointerException e) {
                Text text = new Text("null ");
                root.getChildren().add(text);
            }
            root.getChildren().addAll(texts);
        }
        root.getChildren().add(buttonGo);
        buttonGo.setOnAction(eventGO);
        stage.setScene(scene);
        stage.show();

    }


    public void login() {

        Stage stagee = new Stage();
        Group roots = new Group();
        Button buttonRemove = new Button("go");
        TextField textarea = new TextField();
        textarea.setLayoutY(20);
        textarea.setLayoutX(30.0);
        textarea.setPromptText("name?");
        buttonRemove.setLayoutY(60);
        buttonRemove.setLayoutX(30.0);
        EventHandler<ActionEvent> eventedit = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                Text text = new Text();
                Boolean found = false;
                if (customer.size() != 0) {
                    for (int i = 0; i < customer.size(); i++) {
                        if (customer.get(i).name.equals(textarea.getText())) {
                            customer.get(0).buy();
                            found = true;
                        }
                    }
                    if (!found) {
                        text.setText("you are not registered ");
                    }
                } else {
                    text.setText("no record available ");
                }
                text.setLayoutY(100);
                text.setLayoutX(30);
                roots.getChildren().add(text);
            }
        };
        roots.getChildren().add(textarea);
        roots.getChildren().add(buttonRemove);
        Scene scenes = new Scene(roots, 400, 200, Color.BLUE);
        buttonRemove.setOnAction(eventedit);
        stagee.setScene(scenes);
        stagee.show();

    }

    public void loginToSupplier() {
        Stage stagee = new Stage();
        Group roots = new Group();
        Button buttonRemove = new Button("go");
        TextField textarea = new TextField();
        textarea.setLayoutY(20);
        textarea.setLayoutX(30.0);
        textarea.setPromptText("name?");
        buttonRemove.setLayoutY(60);
        buttonRemove.setLayoutX(30.0);
        EventHandler<ActionEvent> eventedit = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                Text text = new Text();
                Boolean found = false;
                if (suppliers.size() != 0) {
                    for (int i = 0; i < suppliers.size(); i++) {
                        if (suppliers.get(i).name.equals(textarea.getText())) {
                            suppliers.get(0).sell();
                            found = true;
                        }
                    }
                    if (!found) {
                        text.setText("you are not registered ");
                    }
                } else {
                    text.setText("not known ");
                }
                text.setLayoutY(100);
                text.setLayoutX(30);
                roots.getChildren().add(text);
            }
        };
        roots.getChildren().add(textarea);
        roots.getChildren().add(buttonRemove);
        Scene scenes = new Scene(roots, 400, 200, Color.BLUE);
        buttonRemove.setOnAction(eventedit);
        stagee.setScene(scenes);
        stagee.show();

    }

}
