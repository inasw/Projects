package com.example.demo21;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.Window;

public class Customer extends Application {
    public void start(Stage stage) {
    }

    private int creditNumber;
    private String clientAddress;
    public String name;

    public Customer() {
        System.out.println(" ");
    }

    public void setCreditNumber(int credit_number) {
        this.creditNumber = credit_number;
    }

    public void setClientAddress(String address) {
        this.clientAddress = address;
    }

    public int getCreditNumber() {
        return creditNumber;
    }


    public String getClientAddress() {
        return clientAddress;
    }

    public void buy() {//I have to pass the i as parameter
        Button seeProduct = new Button("see all products");
        Button buyProduct = new Button("buy products");
        Button exit = new Button("exit");
        Group rootAdmin = new Group();
        seeProduct.setLayoutY(40);
        seeProduct.setLayoutX(80);
        exit.setLayoutX(60);
        exit.setLayoutY(80);
        buyProduct.setLayoutY(10);
        buyProduct.setLayoutX(80);
        EventHandler<ActionEvent> seeProductEvent = actionEvent -> {
            Window currentWindow = ((Node) actionEvent.getSource()).getScene().getWindow();
            currentWindow.hide();
            Cashier cashier = new Cashier();
            cashier.showAllProducts();
        };
        seeProduct.setOnAction(seeProductEvent);
        EventHandler<ActionEvent> buyProductEvent = actionEvent -> buyStaff();
        buyProduct.setOnAction(buyProductEvent);
        EventHandler<ActionEvent> exitEvent = actionEvent -> System.exit(0);

        exit.setOnAction(exitEvent);
        Scene sceneAdmin = new Scene(rootAdmin, 343, 490, Color.BLUE);
        rootAdmin.getChildren().add(exit);
        rootAdmin.getChildren().add(buyProduct);
        rootAdmin.getChildren().add(seeProduct);
        Stage newStage = new Stage();
        newStage.setTitle("customer page");
        newStage.setScene(sceneAdmin);
        newStage.show();
    }

    public void buyStaff() {

        Text text = new Text();
        TextField textFieldName = new TextField();
        textFieldName.setPromptText("Name");
        TextField textFieldquantity = new TextField();
        textFieldquantity.setPromptText("quantity");

        textFieldquantity.setTextFormatter(new TextFormatter<>(change -> {
            if (change.getControlNewText().matches("[0-9]*")) {
                return change;
            }
            return null;
        }));

        Group root = new Group();
        Scene sceneAdmin = new Scene(root, 400, 300, Color.BLUE);
        Button buy = new Button("buy");
        buy.setLayoutX(30);
        buy.setLayoutY(10);
        text.setLayoutX(80);
        text.setLayoutY(90);
        textFieldName.setLayoutX(0);
        textFieldName.setLayoutY(40);
        textFieldquantity.setLayoutX(200);
        textFieldquantity.setLayoutY(40);
        EventHandler<ActionEvent> addb = actionEvent -> {

            for (int i = 0; i < Cashier.item.size(); i++) {

                if (textFieldName.getText().equals(Cashier.item.get(i).getName())) {
                    text.setText("please enter amount ");
                    if (Integer.parseInt(textFieldquantity.getText()) > Cashier.item.get(i).getQuantity()) {
                        text.setText("sorry we don't have enough amount ");
                    } else {
                        try {
                            if (Integer.parseInt(textFieldquantity.getText()) < 0) {
                                NegativeNumberException neg = new NegativeNumberException("negative number");
                                throw neg;
                            }
                        } catch (NegativeNumberException e) {
                            e.printStackTrace();
                            return;
                        }
                        text.setText("your price is" + (Cashier.item.get(i).getPrice() * Integer.parseInt(textFieldquantity.getText())));
                        Cashier.item.get(i).setQuantity(Cashier.item.get(i).getQuantity() - (Integer.parseInt(textFieldquantity.getText())));

                    }
                }
            }
        };
        buy.setOnAction(addb);
        root.getChildren().add(buy);
        root.getChildren().add(text);
        root.getChildren().add(textFieldName);
        root.getChildren().add(textFieldquantity);
        Stage newStage = new Stage();
        newStage.setTitle("admin page");
        newStage.setScene(sceneAdmin);
        newStage.show();


    }
}
